
/**
 * Write a description of class CellSc here.
 * 
 * @author Ezekiel Elin
 * @version 11/11/2016
 */
public class CellSc {
    public Cell cell;
    public int score = 0;
    
    public CellSc(Cell cell) {
        this.cell = cell;
    }
}
